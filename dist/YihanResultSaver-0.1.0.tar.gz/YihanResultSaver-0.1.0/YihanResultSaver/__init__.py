from .YihanResultSaver import YihanResultSaver

__all__ = ["YihanResultSaver"]